import { call, takeLatest, fork, takeEvery, put } from 'redux-saga/effects';
import * as actions from '../actions/Users'
import * as API from '../utils/ApiUtil'
function* getUsers() {
  try {
    const result = yield call(API.getUsers);
    yield put(actions.getUserSuccess({
      items: result.data.data
    }))
  } catch (error) {
    
  }
} 
function* watchGetUserRequest() {
  yield takeEvery(actions.Types.GET_USERS_REQUEST, getUsers)
}

function* createUsers(actions) {
  try {
    yield call(API.createUser(actions.payload));
    yield getUsers();
  } catch (error) {
    
  }
}

function* watchGetCreateUserRequest() {
  yield takeEvery(actions.Types.CREATE_USERS_REQUEST, createUsers);
}

const UsersSagas = [
  fork(watchGetUserRequest),
  fork(watchGetCreateUserRequest)
];

export default UsersSagas;