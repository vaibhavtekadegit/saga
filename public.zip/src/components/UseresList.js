import React from 'react';
import { Button, ListGroup, ListGroupItem } from 'reactstrap';

import users from '../reducers/users';

const UserList = ({users}) => {
  return (
    <ListGroup>
      {users.sort((a,b) => a.firstName > b.firstName ? 1 : -1).map((user) => {
        return <ListGroupItem key={user.id}>
          <section style={{display: "flex"}}>
              <div style={{flexGrow: 1}}>
                    {user.firstName} {user.lastName}
              </div>
              <div >
                    <Button outline color="danger">
                        Delete
                    </Button>
              </div>
          </section>

        </ListGroupItem>
      })}
    </ListGroup>
  )
}

export default UserList;