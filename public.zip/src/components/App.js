import React, { Component } from 'react';
import { connect } from 'react-redux'
import { addNewuser, getUserRequest } from '../actions/Users'
import NewUserForm from './NewUserForm';
import UserList from './UseresList';

class App extends Component {
  
  constructor(props) {
    super(props);
    this.props.getUserRequest();
  }

  handleSubmit = ({firstName, lastName}) => {
    this.props.addNewuser(firstName, lastName);
  }
  
  render() {
    const users = this.props.users;
    return (
      <div className="container">
        <div className="row">
            <NewUserForm onSubmit={this.handleSubmit}/>
        </div>
        <div className="row">
            <div className="col-md-8">
            <UserList users= {users.items}/>
            </div>
            <div className="col-md-4">
            
            </div>
        </div>
      </div>
    );
  }
}

export default connect(({users}) => ({users}), {
  getUserRequest,
  addNewuser
})(App);
