import React, { Component } from 'react';
import { Button, Form, FormGroup, Input, Label } from 'reactstrap';

class NewUserForm extends Component {

  state = {
    firstName: '',
    lastName: ''
  };

  constructor(props) {
    super();
  }

  adduser = (e) => {
    e.preventDefault();
    this.props.onSubmit({
      firstName: this.state.firstName,
      lastName: this.state.lastName,
    });
  }

  handleChange = e => {
    this.setState({
      [e.target.id]: e.target.value
    });
  };

  render() {
    return(
      <Form onSubmit={this.adduser}>
          <FormGroup>
             <Label>First Name</Label>
             <Input placeholder="first name" onChange={this.handleChange} id="firstName"></Input>
          </FormGroup>
          <FormGroup>
             <Label>Last Name</Label>
             <Input placeholder="Last name" onChange={this.handleChange} id="lastName"></Input>
          </FormGroup>
          <FormGroup>
             <Button block type="submit">Create</Button>
          </FormGroup>
      </Form>
    );
  }
}
export default NewUserForm;