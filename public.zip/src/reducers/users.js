
import {Types} from '../actions/Users';

const INITIAL_STATE = {
  items: []
};

export default function users(state = INITIAL_STATE, action) {
  switch(action.type) {
    case Types.GET_USERS_SUCCESS: {
      return {
        items: action.payload.items
      }
    }
    case Types.CREATE_USERS_SUCCESS: {
      return {
        items: [...state.items, action.payload]
      }
    }
    default : {
      return state;
    }
  }
}