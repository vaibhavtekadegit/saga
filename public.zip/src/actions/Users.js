export const Types = {
  GET_USERS_REQUEST: 'USERS/GET_USERS_REQUEST',
  GET_USERS_SUCCESS: 'USERS/GET_USERS_SUCCESS',
  CREATE_USERS_REQUEST: 'CREATE_USERS_REQUEST',
  CREATE_USERS_SUCCESS: 'CREATE_USERS_REQUEST',
}

export const getUserRequest = () => ({
  type: Types.GET_USERS_REQUEST
});


export const getUserSuccess = ({items}) => ({
  type: Types.GET_USERS_SUCCESS,
  payload: {
    items
  },
});


// export const addNewuser = (firstName, lastName) => ({
//   type: Types.CREATE_USERS_REQUEST, 
//   payload: {firstName, lastName}
// });

export function addNewuser(firstName, lastName){
 return { type: Types.CREATE_USERS_REQUEST, 
    payload: {firstName, lastName}}
}

export function addNewuserSuccess(payload){
  return { type: Types.CREATE_USERS_REQUEST, payload}
 }