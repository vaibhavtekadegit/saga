import axios from 'axios';

function callGet(url) {
  return axios.get(url, {
    params: {
      limit: 1000
    }
  })
}

function callPost(url, payload) {
  return axios.post(url, payload);
}

export function getUsers() {
  return callGet('/users')
}

export function createUser(payload) {
  return callPost('/users', payload);
}